// ==UserScript==
// @name         CSDN、ITeye 彻底去广告，自动展开，去弹窗，免会员，净化剪贴板，防止跳转，上次测试完全可用：2019.08.29
// @version      1.2
// @description  CSDN、ITeye 彻底去广告，去弹窗，免会员，净化剪贴板，不会引起跳转。CSDN博客可以自动展开。
// @author       Sam0230
// @match        *://*.csdn.net/*
// @match        *://www.iteye.com/*
// @grant        none
// @run-at       document-start
// @license      GNU General Public License v3.0 or later
// @namespace https://greasyfork.org/users/207000
// ==/UserScript==

(function() {
    'use strict';
    var addEventListenerOriginal=EventTarget.prototype.addEventListener;
    function addEventListener(type, listener, useCapture) {
        if (type != "copy") {
            addEventListenerOriginal.call(this, type, listener, useCapture);
        }
    }
    EventTarget.prototype.addEventListener = addEventListener;
    function hide(element) {
        if (element != undefined) {
            element.style.position = "fixed";
            element.style.top = "-1000px";
            element.style.position = "-1000px";
        }
    }
    function remove(element) {
        if (element != undefined) {
            element.remove();
        }
    }
    function click(element) {
        if (element != undefined) {
            element.click();
        }
    }
    function operate(operation, elements, callback) {
        if (!elements) {
            return;
        }
        if (!callback) {
            callback = function() {
                return true;
            }
        }
        if (elements.constructor != Array && elements.constructor != HTMLCollection) {
            elements = elements.children;
        }
        if (elements.length != undefined) {
            for (var i = 0; i < elements.length; ++i) {
                if (callback(elements[i], i)) {
                    operation(elements[i]);
                }
            }
        }
    }
    var IntervalID = setInterval(function() {
        if (document.body) {
            operate(hide, document.getElementById("album_detail_wrap"), function(element, num) {
                if (num % 5 == 0) {
                    return true;
                }
            });
            operate(hide, document.body.getElementsByClassName("a_d_pop")[0], function(element, num) {
                if (element.id.slice(0, 1) == "_") {
                    return true;
                }
                if (element.tagName == "DIV" && !element.id && !element.className) {
                    return true;
                }
                if (element.children[0] && element.children[0].src) {
                    if (element.children.length == 1 && (element.children[0].src.slice(0, 24) == "https://pos.baidu.com/s?" || element.children[0].src.slice(0, 24) == "//pos.baidu.com/s?")) {
                        return true;
                    }
                    if (element.children.length == 2 && (element.children[1].src.slice(0, 24) == "https://pos.baidu.com/s?" || element.children[1].src.slice(0, 24) == "//pos.baidu.com/s?")) {
                        return true;
                    }
                }
            });
            operate(hide, document.body, function(element, num) {
                if (element.id.slice(0, 1) == "_") {
                    return true;
                }
                if (element.tagName == "DIV" && !element.id && !element.className) {
                    return true;
                }
                if (element.children[0] && element.children[0].src) {
                    if (element.children.length == 1 && (element.children[0].src.slice(0, 24) == "https://pos.baidu.com/s?" || element.children[0].src.slice(0, 24) == "//pos.baidu.com/s?")) {
                        return true;
                    }
                    if (element.children.length == 2 && (element.children[1].src.slice(0, 24) == "https://pos.baidu.com/s?" || element.children[1].src.slice(0, 24) == "//pos.baidu.com/s?")) {
                        return true;
                    }
                }
            });
            operate(hide, document.body.getElementsByTagName("IMG")[0], function(element, num) {
                if (element.children.length == 1 && element.src.slice(0, 34) == "https://publish-pic-cpu.baidu.com/") {
                    return true;
                }
            });
            if (document.body.getElementsByClassName("vip-caise")[0] != undefined) {
                document.body.getElementsByClassName("vip-caise")[0].style.padding = "0";
            }
            if (document.body.getElementsByClassName("csdn-side-toolbar")[0] != undefined && document.body.getElementsByClassName("csdn-side-toolbar")[0].children[0].dataset.type == "vip") {
                hide(document.body.getElementsByClassName("csdn-side-toolbar")[0].children[0]);
            }
            remove(document.getElementById("kp_box_56"));
            for (let i = 0; i <= 500; i++) {
                hide(document.getElementById("kp_box_"+i));
            }
            hide(document.getElementById("kp_box_394_1047"));
            hide(document.getElementById("kp_box_395_1047"));
            hide(document.getElementById("kp_box_396_1047"));
            hide(document.getElementById("kp_box_397_1047"));
            hide(document.getElementById("kp_box_398_1047"));
            hide(document.getElementById("kp_box_399_1047"));
            hide(document.getElementById("kp_box_219_1046"));
            hide(document.getElementById("adContent"));
            // click(document.getElementById("btn-readmore"));
            // operate(click, document.body.getElementsByClassName("btn-readmore"));
            operate(remove, document.body.getElementsByClassName("hide-article-box hide-article-pos text-center"));
            if (document.getElementById("article_content")) {
                document.getElementById("article_content").style.height = "";
            }
            operate(click, document.body.getElementsByClassName("fouce_close_btn J_fouce_close_btn"));
            operate(hide, document.body.getElementsByClassName("yd_a_d_feed_cla item"));
            operate(hide, document.body.getElementsByClassName("unlogin-tip"));
            operate(hide, document.body.getElementsByClassName("bbs_feed bbs_feed_ad_box"));
            operate(hide, document.body.getElementsByClassName("indexSuperise"));
            operate(hide, document.body.getElementsByClassName("right-item ad_item"));
            operate(hide, document.body.getElementsByClassName("t0 clearfix"));
            operate(hide, document.body.getElementsByClassName("meau-gotop-box"));
            operate(hide, document.body.getElementsByClassName("slide-outer right_top"));
            operate(hide, document.body.getElementsByClassName("quake-slider"));
            operate(hide, document.body.getElementsByClassName("banner-ad-box"));
            operate(hide, document.body.getElementsByClassName("adsbygoogle"));
            operate(hide, document.body.getElementsByClassName("bbs_feed bbs_feed_ad_box"));
            operate(hide, document.body.getElementsByClassName("csdn-tracking-statistics mb8 box-shadow"));
            operate(hide, document.body.getElementsByClassName("recommend-item-box recommend-ad-box"));
            operate(hide, document.body.getElementsByClassName("vip-totast"));
        }
    }, 100);
    setTimeout(function() {
        clearInterval(IntervalID)
    }, 30000);
})();