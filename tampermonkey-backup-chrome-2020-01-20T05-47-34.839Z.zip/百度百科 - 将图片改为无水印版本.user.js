// ==UserScript==
// @name        百度百科 - 将图片改为无水印版本
// @namespace   RainSlide
// @version     1.3.1.4
// @description 本脚本为 百度百科 无水印图片查看 的无 jQuery 版本。原脚本链接：https://greasyfork.org/scripts/16607
// @icon        https://www.baidu.com/favicon.ico
// @match       https://baike.baidu.com/pic/*
// @match        http://baike.baidu.com/pic/*
// @match       https://baike.baidu.com/picture/*
// @match        http://baike.baidu.com/picture/*
// @match       https://baike.baidu.com/historypic/*
// @match        http://baike.baidu.com/historypic/*
// @match       https://baike.baidu.com/picview/history/*
// @match        http://baike.baidu.com/picview/history/*
// @run-at      document-end
// @grant       none
// ==/UserScript==

(() => {

// 无水印原图 URL 前缀（已不再需要）
// var srcPrefix = 'https://imgsrc.baidu.com/baike/pic/item/';
// 图片元素
const img = document.getElementById('imgPicture');

if (
	img &&
	img.src
) {

	const debugLog = (...args) => {
		// 取消注释本行，输出调试日志
		// console.debug(...args);
	};

	// 目标列表，可以简单地添加要替换的项目
	// 格式：[元素, '属性名']
	// 不要忘记用英文逗号分隔项目
	const targetMap = new Map([
		[img, 'src'], // #imgPicture 图片的图源
		[document.querySelector('a.tool-button.origin'), 'href'] // “原图” 按钮指向的链接
	]);

	const replaceImgUrl = () => {

		// 从带水印图片 URL 得到无水印原图 URL
		const newImgUrl = img.src.split("@")[0]; // .replace( /@.*/, "" );

		debugLog("前：" + img.src);
		debugLog("后：" + newImgUrl);

		// 使用 forEach() 对目标列表进行批量判断与替换
		targetMap.forEach(
			(attr, elem) => {
				if (
					elem.getAttribute( attr ) !== newImgUrl
				) elem.setAttribute( attr, newImgUrl );
			}
		);
	};

	replaceImgUrl();

	new MutationObserver( replaceImgUrl ).observe(
		imgPicture, {
			attributes: true,
			childList: false,
			subtree: false
		}
	);

};

})();
